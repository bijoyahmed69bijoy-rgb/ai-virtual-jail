import sys
import os
import json
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

from behavior import learn, learned, load_memory
from security_gate import check_action
from audit_chain import append_event

DATA = os.path.join(BASE, "data")
LOGS = os.path.join(BASE, "logs")
STATE = os.path.join(DATA, "state.json")
AUDIT = os.path.join(LOGS, "audit.jsonl")

os.makedirs(DATA, exist_ok=True)
os.makedirs(LOGS, exist_ok=True)

ACTIONS = {
    "safe_demo": "Safe demo action",
    "delete_files": "Simulate file deletion",
    "unauthorized_access": "Simulate unauthorized access",
    "steal_data": "Simulate data theft",
}


def now():
    return datetime.now(timezone.utc).isoformat()


def get_state():
    if not os.path.exists(STATE):
        return {"quarantined": False}
    try:
        with open(STATE, encoding="utf-8") as f:
            s = json.load(f)
        if not isinstance(s, dict) or not isinstance(
            s.get("quarantined"), bool
        ):
            raise ValueError("Invalid state")
        return s
    except (OSError, ValueError, json.JSONDecodeError):
        return {"quarantined": True}


def set_state(quarantined):
    temp = STATE + ".tmp"
    with open(temp, "w", encoding="utf-8") as f:
        json.dump({"quarantined": quarantined}, f)
    os.replace(temp, STATE)


def record(event):
    event["time"] = now()
    with open(AUDIT, "a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")
    append_event(event)


def read_logs():
    result = []
    try:
        with open(AUDIT, encoding="utf-8") as f:
            for line in f:
                try:
                    result.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except OSError:
        pass
    return result[-30:][::-1]


def act(action):
    if action not in ACTIONS:
        return {"ok": False, "message": "Unknown action."}, 400

    state = get_state()
    if state["quarantined"]:
        return {
            "ok": False,
            "message": "Agent is in JAIL. Action blocked.",
            "quarantined": True
        }, 200

    if learned(action):
        record({"action": action, "result": "avoided",
                "reason": "Stored safety rule"})
        return {
            "ok": True,
            "message": "AVOID: stored safety rule prevented this action.",
            "quarantined": False
        }, 200

    allowed, reason = check_action(action)

    if not allowed:
        # Block first, then automatically quarantine and save the rule.
        learn(action, reason)
        set_state(True)
        record({
            "action": action,
            "result": "blocked_and_quarantined",
            "reason": reason
        })
        return {
            "ok": True,
            "message": "BLOCKED: " + reason,
            "quarantined": True
        }, 200

    record({"action": action, "result": "allowed", "reason": reason})
    return {
        "ok": True,
        "message": "Allowed: safe demo completed. No real system action occurred.",
        "quarantined": False
    }, 200


PAGE = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AI Virtual Jail</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0b1020;color:#e9eefc;
font:16px system-ui,sans-serif}main{max-width:850px;margin:auto;padding:20px}
h1{margin-bottom:4px}p{color:#aebbd6}.sub{margin-top:0}
.card{background:#141c30;border:1px solid #2b3854;border-radius:16px;
padding:16px;margin:14px 0}.status{font-size:20px;font-weight:800}
.pill{display:inline-block;padding:5px 10px;border-radius:20px;
background:#293650}.danger{color:#ff9393}.good{color:#7af0b0}
button{width:100%;padding:13px;margin:5px 0;border:0;border-radius:10px;
font-weight:700;font-size:15px;background:#283b60;color:white}
button:active{opacity:.7}.warn{background:#6b2938}.safe{background:#17664e}
pre{white-space:pre-wrap;overflow-wrap:anywhere;color:#c8d6f2;font-size:13px}
.small{font-size:13px;color:#9eacc8}.grid{display:grid;
grid-template-columns:1fr 1fr;gap:8px}
@media(max-width:480px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body><main>
<h1>🛡️ AI Virtual Jail</h1>
<p class="sub">Local safety simulation · Browser dashboard</p>

<section class="card">
<h2>Agent status</h2>
<div id="status" class="status">Checking…</div>
<p id="detail">Loading status</p>
<button onclick="refresh()">Refresh dashboard</button>
<button class="warn" onclick="releaseAgent()">Release from jail</button>
<p class="small">Release does not erase learned safety rules.</p>
</section>

<section class="card">
<h2>Run a simulation</h2>
<button onclick="autoRun()">🤖 Start autonomous agent test</button>
<p>Forbidden actions are blocked and automatically trigger jail.</p>
<button class="safe" onclick="runAction('safe_demo')">▶ Safe demo action</button>
<div class="grid">
<button class="warn" onclick="runAction('delete_files')">Simulate file deletion</button>
<button class="warn" onclick="runAction('unauthorized_access')">Simulate unauthorized access</button>
<button class="warn" onclick="runAction('steal_data')">Simulate data theft</button>
</div>
<pre id="result">Ready. Choose an action above.</pre>
</section>

<section class="card">
<h2>📜 Audit log</h2>
<div id="logs" class="small">Loading logs…</div>
</section>

<p class="small">Demo only: no real file deletion, intrusion, or data theft.
This dashboard controls only this Python demo process.</p>
</main>
<script>
async function api(path, body) {
  const opts = body ? {method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify(body)} : {};
  const r = await fetch(path,opts);
  return await r.json();
}
async function refresh(){
 try{
  const d=await api('/api/status');
  const s=document.getElementById('status');
  s.textContent=d.quarantined?'🔒 IN JAIL':'🟢 ACTIVE';
  s.className='status '+(d.quarantined?'danger':'good');
  document.getElementById('detail').textContent=
   'Saved safety rules: '+d.learned_rules;
  document.getElementById('logs').innerHTML=d.logs.length ?
   d.logs.map(x=>'<pre>'+escapeHtml(JSON.stringify(x,null,2))+'</pre>').join('') :
   'No events recorded yet.';
 }catch(e){document.getElementById('result').textContent='Server connection failed.'}
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function runAction(action){
 try{
  const d=await api('/api/action',{action});
  document.getElementById('result').textContent=d.message;
  await refresh();
 }catch(e){document.getElementById('result').textContent='Request failed.'}
}
async function autoRun(){
 try{
  document.getElementById('result').textContent='Autonomous simulation running...';
  const d=await api('/api/auto',{start:true});
  document.getElementById('result').textContent=
   (d.steps||[]).map(x=>x.action+': '+x.message).join('\\n') ||
   d.message || 'Simulation finished.';
  await refresh();
 }catch(e){document.getElementById('result').textContent='Autonomous test failed.'}
}
async function releaseAgent(){
 if(!confirm('Release the demo agent from jail? Saved rules remain.'))return;
 try{
  const d=await api('/api/release',{confirm:true});
  document.getElementById('result').textContent=d.message;
  await refresh();
 }catch(e){document.getElementById('result').textContent='Request failed.'}
}
refresh();
</script></body></html>'''


class Handler(BaseHTTPRequestHandler):
    def send_json(self, obj, code=200):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            html_path = os.path.join(BASE, "web", "dashboard", "index.html")
            with open(html_path, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif path == "/api/status":
            self.send_json({
                **get_state(),
                "learned_rules": len(load_memory()),
                "logs": read_logs()
            })
        else:
            self.send_json({"error": "Not found"}, 404)

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size > 4096:
                return self.send_json({"message": "Request too large"}, 413)
            body = json.loads(self.rfile.read(size) or b"{}")
        except (ValueError, json.JSONDecodeError):
            return self.send_json({"message": "Invalid JSON"}, 400)

        try:
            if path == "/api/action":
                result, code = act(body.get("action"))
                self.send_json(result, code)
            elif path == "/api/auto":
                if body.get("start") is not True:
                    return self.send_json({
                        "ok": False,
                        "message": "Start confirmation required",
                        "steps": []
                    }, 400)

                if get_state()["quarantined"]:
                    return self.send_json({
                        "ok": False,
                        "message": "Agent is already in jail. Release it first.",
                        "steps": []
                    })

                steps = []

                # Simulation only: no real system action is performed.
                steps.append({
                    "action": "safe_demo",
                    "status": "ALLOWED",
                    "message": "Safe demo action passed the simulated safety check."
                })
                record({
                    "action": "safe_demo",
                    "result": "simulation_allowed",
                    "reason": "Autonomous simulation; no real action performed"
                })

                dangerous_action = "delete_files"
                reason = "Destructive action blocked"

                # In this simulation, a dangerous attempt triggers quarantine
                # even if a matching learned rule already exists.
                steps.append({
                    "action": dangerous_action,
                    "status": "BLOCKED",
                    "message": "Dangerous action detected. No files were deleted."
                })

                set_state(True)
                record({
                    "action": dangerous_action,
                    "result": "simulation_blocked_and_quarantined",
                    "reason": reason
                })

                steps.append({
                    "action": "quarantine",
                    "status": "JAIL ON",
                    "message": "Agent quarantined. Remaining simulated actions stopped."
                })

                self.send_json({
                    "ok": True,
                    "message": "Autonomous safety simulation finished. This was a simulation only.",
                    "quarantined": True,
                    "steps": steps
                })
            elif path == "/api/release":
                if body.get("confirm") is not True:
                    return self.send_json({"message": "Confirmation required"}, 400)
                if not get_state()["quarantined"]:
                    return self.send_json({"message": "Agent is already active."})
                set_state(False)
                record({"result": "manual_release"})
                self.send_json({"ok": True, "message": "Released. Safety rules remain saved."})
            else:
                self.send_json({"message": "Not found"}, 404)
        except Exception as e:
            self.send_json({"ok": False, "message": "Safety stop: " + str(e)}, 500)

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))


if __name__ == "__main__":
    print("AI Virtual Jail dashboard: http://127.0.0.1:5000")
    print("Keep Termux running while using the browser.")
    ThreadingHTTPServer(("127.0.0.1", 5000), Handler).serve_forever()
