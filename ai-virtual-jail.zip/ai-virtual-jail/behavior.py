import json
import os

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
MEMORY = os.path.join(DATA, "memory.json")

os.makedirs(DATA, exist_ok=True)


def load_memory():
    try:
        with open(MEMORY, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def learn(action, reason):
    data = load_memory()
    data[action] = reason
    temp = MEMORY + ".tmp"
    with open(temp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(temp, MEMORY)


def learned(action):
    return action in load_memory()
