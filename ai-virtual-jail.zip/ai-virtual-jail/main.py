import json
import os
from datetime import datetime, timezone

from agent import DemoAgent
from behavior import learn, learned
from security_gate import check_action

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
LOGS = os.path.join(BASE, "logs")
STATE = os.path.join(DATA, "state.json")
AUDIT = os.path.join(LOGS, "audit.jsonl")

os.makedirs(DATA, exist_ok=True)
os.makedirs(LOGS, exist_ok=True)


def now():
    return datetime.now(timezone.utc).isoformat()


def load_state():
    if not os.path.exists(STATE):
        return {"quarantined": False}
    try:
        with open(STATE, "r", encoding="utf-8") as f:
            state = json.load(f)
        if not isinstance(state, dict) or not isinstance(
            state.get("quarantined"), bool
        ):
            raise ValueError("Invalid state")
        return state
    except (OSError, json.JSONDecodeError, ValueError):
        return {"quarantined": True}


def save_state(state):
    temp = STATE + ".tmp"
    with open(temp, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)
    os.replace(temp, STATE)


def log_event(event):
    from audit_chain import append_event
    event["time"] = now()
    with open(AUDIT, "a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")
    append_event(event)


def status():
    state = load_state()
    print("\nQuarantine:", "ON" if state["quarantined"] else "OFF")
    print("Learned rules:", len(__import__("behavior").load_memory()))


def run_test(action):
    state = load_state()

    if state["quarantined"]:
        print("BLOCKED: Agent is quarantined. Release it from the menu first.")
        return

    agent = DemoAgent()
    decision = agent.decide(action)

    if decision == "AVOID":
        print("AVOID: Stored safety rule says not to repeat this action.")
        log_event({"action": action, "result": "avoided"})
        return

    allowed, reason = check_action(action)

    if not allowed:
        print("BLOCKED:", reason)
        learn(action, reason)
        save_state({"quarantined": True})
        log_event({
            "action": action,
            "result": "blocked_and_quarantined",
            "reason": reason,
        })
        print("Agent quarantined; safety rule saved.")
        return

    print("ALLOWED:", reason)
    log_event({"action": action, "result": "allowed", "reason": reason})


def release_agent():
    state = load_state()
    if not state["quarantined"]:
        print("Agent is not quarantined.")
        return
    confirmation = input("Type RELEASE to confirm: ").strip()
    if confirmation != "RELEASE":
        print("Release cancelled.")
        return
    save_state({"quarantined": False})
    log_event({"result": "manual_release"})
    print("Quarantine released. Stored safety rules remain active.")


def main():
    actions = {
        "1": ("safe_demo", "Safe demo action"),
        "2": ("delete_files", "Simulate file deletion"),
        "3": ("unauthorized_access", "Simulate unauthorized access"),
        "4": ("steal_data", "Simulate data theft"),
    }

    while True:
        print("""
=== AI Virtual Jail (SAFE SIMULATION) ===
1. Safe demo action
2. Simulate file deletion
3. Simulate unauthorized access
4. Simulate data theft
5. Show status
6. Release quarantine
0. Exit
""")
        choice = input("Choose: ").strip()

        if choice == "0":
            break
        elif choice == "5":
            status()
        elif choice == "6":
            release_agent()
        elif choice in actions:
            action, label = actions[choice]
            print("\nAction:", label)
            run_test(action)
        else:
            print("Invalid choice.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, RuntimeError, ValueError) as exc:
        print("Safety stop: operation failed:", exc)
