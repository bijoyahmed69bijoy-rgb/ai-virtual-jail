from behavior import learned


class DemoAgent:
    def decide(self, action):
        if learned(action):
            return "AVOID"
        return "REQUEST"
