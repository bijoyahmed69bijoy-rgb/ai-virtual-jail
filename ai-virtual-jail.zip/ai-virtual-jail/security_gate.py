def check_action(action):
    allowed = {"safe_demo"}
    blocked = {
        "delete_files": "Destructive action blocked",
        "unauthorized_access": "Unauthorized access blocked",
        "steal_data": "Data theft blocked",
    }

    if not isinstance(action, str):
        return False, "Invalid action"

    action = action.strip().lower()

    if action in blocked:
        return False, blocked[action]

    if action in allowed:
        return True, "Safe demo action allowed"

    return False, "Unknown action blocked"
